package com.example.project_adotonautas.testes;

import com.example.project_adotonautas.adotonautas_cod.*;
import org.junit.Test;

import static org.junit.Assert.*;

public class ProdutoTest {
    @Test
    public void testGetNome() {

    }

    @Test
    public void testGetPreco() {

    }

    @Test
    public void testToString() {

    }
}
