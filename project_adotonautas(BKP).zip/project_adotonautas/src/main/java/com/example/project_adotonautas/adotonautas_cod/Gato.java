package com.example.project_adotonautas.adotonautas_cod;
public class Gato extends Animal {
    public Gato(String nome, int idade, String raca) {
        super(nome, idade, raca);
    }
}